<?php

namespace TattoStudioPlugin\Controllers;

use Amostajo\LightweightMVC\Controller;

class PostTypesController extends Controller
{

	// Artists 
	public function registerArtists(){

    $args = array(
      'labels' => array(
				'name'               => __( 'Artists', 'tattoostudio' ),
				'singular_name'      => __( 'Artist', 'tattoostudio' ),
				'menu_name'          => __( 'Artists', 'tattoostudio' ),
				'name_admin_bar'     => __( 'Artist', 'tattoostudio' ),
				'add_new'            => __( 'Add New', 'tattoostudio' ),
				'add_new_item'       => __( 'Add New Artist', 'tattoostudio' ),
				'new_item'           => __( 'New Artist', 'tattoostudio' ),
				'edit_item'          => __( 'Edit Artist', 'tattoostudio' ),
				'view_item'          => __( 'View Artist', 'tattoostudio' ),
				'all_items'          => __( 'All Artists', 'tattoostudio' ),
				'search_items'       => __( 'Search Artists', 'tattoostudio' ),
				'parent_item_colon'  => __( 'Parent Artists:', 'tattoostudio' ),
				'not_found'          => __( 'No artists found.', 'tattoostudio' ),
				'not_found_in_trash' => __( 'No artists found in Trash.', 'tattoostudio' )
    	),
			'public' => true,
			'publicty_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			'rewrite' => array( 'slug' => 'artist' ),
			'capability_type' => 'post',
			'hierarchical' => true,
			'menu_position' => 5,
			'supports' => array(
      	'title', 'editor', 'thumbnail'
    	),
    	'menu_icon' => 'dashicons-id-alt'
    );

    register_post_type('tattoostudio-artists', $args);

  }

	public function editArtistsColumns($columns){

	  $columns = array(
	      'cb' => "<input type=\"checkbox\" />",
	      'title'     => __( 'Title', 'tattoostudio' ),
	      'thumbnail' =>  __( 'Thumbnail', 'tattoostudio' ),
	      'id' =>  __( 'ID', 'tattoostudio' ),
	      'date' =>  __( 'Date', 'tattoostudio' ),
	  );

	  return $columns;
	}

	public function showArtistsColumns($column, $post_id){
		switch ( $column )
		{
		  case 'thumbnail':
		    if(has_post_thumbnail($post_id)):
		        echo get_the_post_thumbnail( $post_id, array(50,50) );
		    else:
		        echo __( "No thumbnail", 'tattoostudio' );
		    endif;
		    break;
		  case 'id':
		  	echo get_the_ID();
		    break;
		}
	}

	// GALLERY
  public function registerGalleries(){

    $args = array(
			'labels' => array(
				'name'               => __( 'Galleries', 'tattoostudio' ),
				'singular_name'      => __( 'Gallery', 'tattoostudio' ),
				'menu_name'          => __( 'Galleries', 'tattoostudio' ),
				'name_admin_bar'     => __( 'Gallery', 'tattoostudio' ),
				'add_new'            => __( 'Add New', 'tattoostudio' ),
				'add_new_item'       => __( 'Add New Gallery', 'tattoostudio' ),
				'new_item'           => __( 'New Gallery', 'tattoostudio' ),
				'edit_item'          => __( 'Edit Gallery', 'tattoostudio' ),
				'view_item'          => __( 'View Gallery', 'tattoostudio' ),
				'all_items'          => __( 'All Galleries', 'tattoostudio' ),
				'search_items'       => __( 'Search Galleries', 'tattoostudio' ),
				'parent_item_colon'  => __( 'Parent Galleries:', 'tattoostudio' ),
				'not_found'          => __( 'No Galleries found.', 'tattoostudio' ),
				'not_found_in_trash' => __( 'No Galleries found in Trash.', 'tattoostudio' )
      ),
			'public' => true,
			'publicty_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			'rewrite' => array( 'slug' => 'gallery' ),
			'capability_type' => 'post',
			'hierarchical' => true,
			'menu_position' => 5,
			'supports' => array(
			  'title'
			),
			'menu_icon' => 'dashicons-images-alt2',
	  );

    register_post_type('tattoostudio-gallery', $args);
  }


}