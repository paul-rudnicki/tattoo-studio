<?php
/*

Plugin Name: Tatto Studio Plugin

Plugin URI: https://tattoo.futureteam.pro

Description: Adding more functionality for tatto studio theme, such as custom post types etc.

Version: 1.0

Author: Paul Rudnicki

Author URI: https://futureteam.pro

*/

//------------------------------------------------------------
//
// NOTE:
//
// Try NOT to add any code line in this file.
//
// Use "plugin\Main.php" to add your hooks.
//
//------------------------------------------------------------
require_once( plugin_dir_path( __FILE__ ) . 'boot/bootstrap.php' );