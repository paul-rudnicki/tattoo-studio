<?php

namespace TattoStudioPlugin;

use Amostajo\WPPluginCore\Plugin;

/**
 * Main class.
 * Registers HOOKS used within the plugin.
 * Acts like a bridge or router of actions between Wordpress and the plugin.
 *
 * @link http://wordpress-dev.evopiru.com/documentation/main-class/
 * @version 1.0
 */
class Main extends Plugin
{
	/**
	 * Declares public HOOKS.
	 * - Can be removed if not used.
	 * @since 1.0
	 */
	public function init()
	{
		$this->add_action( 'init', 'PostTypesController@registerArtists' );
		$this->add_action( 'init', 'PostTypesController@registerGalleries' );
		$this->add_filter( 'manage_edit-tattoostudio-artists_columns', 'PostTypesController@editArtistsColumns' );
		$this->add_action( 'manage_tattoostudio-artists_posts_custom_column', 'PostTypesController@showArtistsColumns', 10, 2 );
	}

	/**
	 * Declares admin dashboard HOOKS.
	 * - Can be removed if not used.
	 * @since 1.0
	 */
	public function on_admin()
	{
		// i.e.
		// add_action( 'admin_init', [ &$this, 'admin_init' ] );
		// 
		// $this->add_action( 'admin_init', 'AdminController@init' );
	}
}